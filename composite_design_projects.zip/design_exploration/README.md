## Rhino/Grasshopper Design Exploration

This folder contains a **Python script** and a **placeholder Grasshopper file** to
illustrate how you might generate and analyse variable–angle tow (VAT) fibre
paths within Rhino/Grasshopper.  Rhino’s Python API (`rhinoscriptsyntax`) is
used to procedurally create fibre trajectories across a rectangular panel.

### Files

| File | Purpose |
| --- | --- |
| `rhino_script.py` | Python script that can be run inside Rhino’s _EditPythonScript_ editor.  It asks for panel dimensions and generates a set of fibre paths whose orientations vary smoothly across the panel width.  The script highlights how to sample an orientation function, build polylines, and ensure steering radii remain within Automated Fibre Placement (AFP) limits. |
| `placeholder.gh` | Empty Grasshopper definition where you can import the generated curves and build more complex VAT laminates.  You can add parameter sliders, optimisation components, and link to Python code using _GhPython_ or the `ghpythonremote` package. |

### Running the script

1. Open Rhino (version 7 or later).
2. From the _PythonScript_ menu choose **Edit** to open the script editor.
3. Paste the contents of `rhino_script.py` into the editor and run it.
4. Specify the panel width, height, number of fibre paths and resolution when prompted.
5. The script will generate fibre centrelines as Rhino curves.  These can be exported to Grasshopper for further processing or fed into Automated Fibre Placement software.

### Orientation function

The script defines a simple orientation function `theta(x)` that varies the
fibre angle sinusoidally between `-30°` and `+30°` across the panel width.  You
can modify `theta(x)` to implement more sophisticated distributions (e.g.,
hyperbolic, polynomial or optimiser–driven fields).  The key idea is to
parameterise the fibre path by a function and then discretise it into a
polyline for fabrication.

### Disclaimer

The supplied Grasshopper file is intentionally empty; it serves as a starting
point for your own visual programming.  In a production environment you would
use Grasshopper components to control ply build–up, export to simulation
software, and integrate with optimisation loops—exactly the workflow described
in the Airbus internship posting.

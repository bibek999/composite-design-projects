"""Generate variable–angle tow fibre paths on a rectangular panel.

This script is designed to be run inside Rhino's Python environment.  It
demonstrates how to programmatically generate fibre centreline curves for
Variable–Angle Tow (VAT) laminates.  The orientation of the fibres varies
across the panel width according to a user–defined function.  The resulting
polylines can be exported to Grasshopper for further processing or directly
used in Automated Fibre Placement (AFP) studies.

Usage:

    1. Open Rhino and launch the Python script editor (_EditPythonScript_).
    2. Paste the contents of this file and run it.
    3. Input the panel width, height, number of fibre paths, and resolution when
       prompted.

Notes:

    * Steering radius constraints are considered implicitly via the resolution
      parameter; a finer resolution produces smoother paths and smaller
      curvature.  For real AFP checks, you would compute curvature along the
      path and compare it to the machine's minimum steering radius.
    * The orientation function `theta(x)` can be modified to implement any
      desired fibre angle distribution, including those optimised by external
      algorithms.

Author: Airbus optimisation internship demo
"""

import math

import rhinoscriptsyntax as rs


def theta(x: float, width: float) -> float:
    """Orientation function for VAT fibres.

    Returns the fibre angle (in degrees) at position x (0 ≤ x ≤ width).  By
    default the function varies sinusoidally between –30° and +30° across the
    panel width.  Modify this function to implement more complex distributions.

    Parameters
    ----------
    x : float
        Horizontal coordinate (mm).
    width : float
        Panel width (mm).

    Returns
    -------
    float
        Fibre angle in degrees at coordinate x.
    """
    # Map x from [0, width] to [0, π] for one half sine wave
    return 30.0 * math.sin(math.pi * x / width)


def generate_paths(width: float, height: float, n_paths: int, resolution: int) -> None:
    """Generate fibre centreline curves on the XY plane.

    The function creates `n_paths` polylines representing fibre centrelines.
    Each path spans the width of the panel.  Along the path, points are
    computed at uniform x increments and offset in the y–direction according to
    the local fibre orientation.  The y–offset ensures adjacent paths remain
    evenly spaced.

    Parameters
    ----------
    width, height : float
        Dimensions of the rectangular panel (mm).
    n_paths : int
        Number of fibre paths to generate.
    resolution : int
        Number of segments used to discretise each fibre path.
    """
    # Vertical spacing between paths
    dy = height / float(n_paths)
    # Loop through each path
    for i in range(n_paths):
        y_base = i * dy
        pts = []
        for j in range(resolution + 1):
            x = j * width / float(resolution)
            angle_deg = theta(x, width)
            angle_rad = math.radians(angle_deg)
            # local direction vector (unit length)
            dx = math.cos(angle_rad)
            dy_local = math.sin(angle_rad)
            # Offset the point in y by half the fibre spacing times the sine
            y = y_base + dy * 0.5 * (dy_local)
            pts.append([x, y, 0.0])
        rs.AddPolyline(pts)


def main():
    rs.MessageBox("This script generates variable–angle tow paths on a panel.")
    width = rs.GetReal("Panel width (mm)", 500.0, 10.0)
    height = rs.GetReal("Panel height (mm)", 500.0, 10.0)
    n_paths = rs.GetInteger("Number of fibre paths", 6, 1)
    resolution = rs.GetInteger("Discretisation resolution", 50, 10)
    if width and height and n_paths and resolution:
        generate_paths(width, height, n_paths, resolution)
        rs.MessageBox("Finished generating fibre paths.")


if __name__ == '__main__':
    main()

## VAT Laminate Optimiser

This module demonstrates how to apply **Classical Laminate Theory (CLT)** and numerical optimisation to design variable–angle tow (VAT) composite laminates.  Given a stack of orthotropic plies, the script calculates the laminate bending stiffness and optimises the fibre orientation angles to maximise stiffness.

### Features

* Implements CLT to compute the in–plane (`A`), coupling (`B`), and bending (`D`) stiffness matrices for arbitrary layups.
* Supports both gradient‐based optimisation (BFGS) and metaheuristic global search (Differential Evolution).
* Benchmarks algorithms on a simple objective: **maximise the bending stiffness `Dₓₓ`** of a symmetric four–ply laminate subject to ±45° angle bounds.
* Generates a small report summarising the optimum angles and resulting stiffness.

### Usage

Run the optimiser from the command line:

```bash
python optimise_vat.py
```

The script prints intermediate progress and final results.  You can modify the material properties, ply count, or objective function by editing `optimise_vat.py`.

### Files

* `optimise_vat.py` – main script implementing the optimisation and reporting.
* `utils.py` – helper functions for CLT (computation of transformed reduced stiffness and laminate ABD matrices).

### Disclaimer

The implementation here is intended for demonstration and educational purposes.  Real VAT laminates require modelling variable fibre paths across the laminate surface and integrating fibre steering constraints.  Nonetheless, the underlying optimisation patterns (defining a merit function, choosing an algorithm, and benchmarking results) mirror the workflow expected in the Airbus internship.

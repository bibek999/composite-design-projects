"""Utility functions for classical laminate theory (CLT).

This module implements helper routines for computing the reduced stiffness matrix
of an orthotropic lamina, transforming it for a given ply orientation, and
assembling the laminate A, B and D matrices.  These functions are used in
`optimise_vat.py` to form the optimisation objective.

Author: Airbus optimisation internship demo
"""

import numpy as np

def lamina_q(E1: float, E2: float, v12: float, G12: float) -> np.ndarray:
    """Return the reduced stiffness matrix Q for an orthotropic lamina under
    plane stress.

    Parameters
    ----------
    E1, E2 : float
        Young's moduli in fibre and transverse directions.
    v12 : float
        Poisson's ratio (major) of the lamina.
    G12 : float
        In–plane shear modulus.

    Returns
    -------
    Q : ndarray (3x3)
        Reduced stiffness matrix for plane stress.
    """
    v21 = v12 * E2 / E1
    denom = 1.0 - v12 * v21
    Q11 = E1 / denom
    Q22 = E2 / denom
    Q12 = v12 * E2 / denom
    Q66 = G12
    Q = np.array([[Q11, Q12, 0.0],
                  [Q12, Q22, 0.0],
                  [0.0, 0.0, Q66]])
    return Q


def transform_q(Q: np.ndarray, theta_deg: float) -> np.ndarray:
    """Transform the reduced stiffness matrix Q for a ply at orientation theta.

    Transformation follows the standard equations from classical laminate theory.

    Parameters
    ----------
    Q : ndarray (3x3)
        Reduced stiffness matrix of the lamina in its principal material axes.
    theta_deg : float
        Orientation angle in degrees measured from the laminate x–axis.

    Returns
    -------
    Q_bar : ndarray (3x3)
        Transformed reduced stiffness matrix in laminate coordinates.
    """
    theta = np.deg2rad(theta_deg)
    m = np.cos(theta)
    n = np.sin(theta)
    Q11, Q12, _, Q22, _, Q66 = Q[0, 0], Q[0, 1], Q[0, 2], Q[1, 1], Q[1, 2], Q[2, 2]
    # Intermediate terms
    Q11p = Q11 * m**4 + 2 * (Q12 + 2 * Q66) * m**2 * n**2 + Q22 * n**4
    Q22p = Q11 * n**4 + 2 * (Q12 + 2 * Q66) * m**2 * n**2 + Q22 * m**4
    Q12p = (Q11 + Q22 - 4 * Q66) * m**2 * n**2 + Q12 * (m**4 + n**4)
    Q16p = (Q11 - Q12 - 2 * Q66) * m**3 * n - (Q22 - Q12 - 2 * Q66) * m * n**3
    Q26p = (Q11 - Q12 - 2 * Q66) * m * n**3 - (Q22 - Q12 - 2 * Q66) * m**3 * n
    Q66p = (Q11 + Q22 - 2 * Q12 - 2 * Q66) * m**2 * n**2 + Q66 * (m**4 + n**4)
    Q_bar = np.array([
        [Q11p, Q12p, Q16p],
        [Q12p, Q22p, Q26p],
        [Q16p, Q26p, Q66p],
    ])
    return Q_bar


def laminate_abd(Qbars: list, thicknesses: list) -> tuple:
    """Compute the laminate A, B, D matrices for a stack of plies.

    Parameters
    ----------
    Qbars : list of ndarray
        Transformed reduced stiffness matrices for each ply (3x3).
    thicknesses : list of float
        Thickness of each ply.  Must be the same length as `Qbars`.

    Returns
    -------
    A, B, D : tuple of ndarray
        The in–plane, coupling and bending stiffness matrices (each 3x3).
    """
    assert len(Qbars) == len(thicknesses), "Number of plies and thicknesses must match"
    n = len(thicknesses)
    total_thickness = sum(thicknesses)
    # z coordinates measured from mid–plane.  z=0 at the laminate mid–plane.
    z_bot = -total_thickness / 2.0
    A = np.zeros((3, 3))
    B = np.zeros((3, 3))
    D = np.zeros((3, 3))
    for i in range(n):
        t = thicknesses[i]
        z_top = z_bot + t
        Qb = Qbars[i]
        delta_z = z_top - z_bot
        A += Qb * delta_z
        B += 0.5 * Qb * (z_top**2 - z_bot**2)
        D += (1.0 / 3.0) * Qb * (z_top**3 - z_bot**3)
        z_bot = z_top
    return A, B, D

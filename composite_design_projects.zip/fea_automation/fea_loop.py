"""Parametric FEA and optimisation of a 1D beam.

The objective is to minimise the end deflection (compliance) of a bar by
optimising the cross–sectional area distribution along its length while
maintaining a fixed total volume.  A simple Euler–Bernoulli beam model is
implemented with linear elements, and the optimisation problem is solved using
both gradient–based and metaheuristic algorithms.

Author: Airbus optimisation internship demo
"""

import time
from typing import Dict, Tuple

import numpy as np
from scipy import optimize


def assemble_stiffness(E: float, areas: np.ndarray, length: float) -> np.ndarray:
    """Assemble the global stiffness matrix for a 1D bar with variable area.

    Parameters
    ----------
    E : float
        Young's modulus.
    areas : ndarray of shape (n_elem,)
        Cross–sectional area for each finite element.
    length : float
        Total length of the bar.

    Returns
    -------
    K : ndarray (n_nodes x n_nodes)
        Global stiffness matrix.
    """
    n_elem = len(areas)
    h = length / n_elem
    n_nodes = n_elem + 1
    K = np.zeros((n_nodes, n_nodes))
    for i in range(n_elem):
        k_e = E * areas[i] / h * np.array([[1.0, -1.0], [-1.0, 1.0]])
        K[i:i+2, i:i+2] += k_e
    return K


def beam_compliance(areas: np.ndarray, material: Dict, length: float, target_volume: float, penalty: float) -> float:
    """Compute compliance with a volume penalty for a given area distribution.

    The bar is fixed at the left end (u0 = 0) and subjected to a unit load at the
    right end.  Compliance is defined as the end displacement multiplied by the
    applied load.

    Parameters
    ----------
    areas : ndarray
        Design variables (areas for each element).
    material : dict
        Contains 'E' (Young's modulus).
    length : float
        Total length of the bar.
    target_volume : float
        Target total volume (area * length) constraint.
    penalty : float
        Penalty factor for violating the volume constraint.

    Returns
    -------
    float
        Compliance plus penalty term.
    """
    E = material['E']
    n_elem = len(areas)
    n_nodes = n_elem + 1
    # Assemble stiffness matrix
    K = assemble_stiffness(E, areas, length)
    # Apply boundary conditions: fix left end (u0=0)
    K_reduced = K[1:, 1:]
    # Force vector: unit load at last node
    F = np.zeros(n_nodes)
    F[-1] = 1.0
    F_reduced = F[1:]
    # Solve for displacements
    u = np.linalg.solve(K_reduced, F_reduced)
    # End displacement is the last entry of u
    u_end = u[-1]
    compliance = u_end  # since force is 1 N
    # Volume penalty
    current_volume = np.sum(areas) * (length / n_elem)
    volume_penalty = penalty * (current_volume - target_volume) ** 2
    return compliance + volume_penalty


def optimise_area_distribution(material: Dict, length: float, n_elem: int,
                               A_min: float, A_max: float) -> Dict[str, Dict]:
    """Optimise the area distribution using local and global algorithms.

    Parameters
    ----------
    material : dict
        Material properties (contains 'E').
    length : float
        Length of the bar.
    n_elem : int
        Number of finite elements.
    A_min, A_max : float
        Lower and upper bounds for cross–sectional area in each element.

    Returns
    -------
    results : dict
        Keys 'bfgs' and 'de' each containing 'areas', 'compliance' and 'time'.
    """
    target_volume = 0.5 * (A_min + A_max) * length  # mean area times length
    penalty = 1e7  # penalty factor for volume constraint
    bounds = [(A_min, A_max)] * n_elem

    def obj(x):
        return beam_compliance(x, material, length, target_volume, penalty)

    # Initial guess: uniform area at midpoint
    x0 = np.array([(A_min + A_max) / 2.0] * n_elem)
    results = {}
    # Local optimiser (L-BFGS-B)
    t0 = time.time()
    bfgs_res = optimize.minimize(obj, x0, method='L-BFGS-B', bounds=bounds)
    dt_bfgs = time.time() - t0
    areas_bfgs = bfgs_res.x
    compliance_bfgs = beam_compliance(areas_bfgs, material, length, target_volume, penalty)
    results['bfgs'] = {'areas': areas_bfgs, 'compliance': compliance_bfgs, 'time': dt_bfgs}
    # Global search (Differential Evolution)
    t0 = time.time()
    de_res = optimize.differential_evolution(obj, bounds=bounds, tol=1e-3, polish=True)
    dt_de = time.time() - t0
    areas_de = de_res.x
    compliance_de = beam_compliance(areas_de, material, length, target_volume, penalty)
    results['de'] = {'areas': areas_de, 'compliance': compliance_de, 'time': dt_de}
    return results


def main():
    material = {'E': 210e9}  # Pa (typical for steel)
    length = 1.0  # metres
    n_elem = 10
    A_min = 1e-4  # m^2
    A_max = 1e-3  # m^2
    print("Optimising area distribution for a 1D bar to minimise compliance...")
    results = optimise_area_distribution(material, length, n_elem, A_min, A_max)
    for method, res in results.items():
        print(f"\nMethod: {method.upper()}")
        print(f"  Areas (m^2): {np.array2string(res['areas'], precision=6, separator=', ')}")
        print(f"  Compliance: {res['compliance']:.6e}")
        print(f"  Time: {res['time']:.3f} s")


if __name__ == '__main__':
    main()

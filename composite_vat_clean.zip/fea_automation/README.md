## Parametric FEA Automation

This mini–project showcases how to script a **finite element analysis (FEA)** loop
entirely in Python.  The goal is to minimise the compliance (flexibility) of a
one–dimensional beam by optimising the cross‐sectional area distribution while
respecting a fixed total volume.  The script automatically assembles the
stiffness matrix, applies boundary conditions, solves the system for each
candidate design, and feeds the result into an optimiser.

### Highlights

* Implements a simple Euler–Bernoulli beam element and assembles the global
  stiffness matrix for an arbitrary number of elements.
* Defines an objective function combining end–deflection (compliance) and a
  volume penalty, enabling optimisation under resource constraints.
* Benchmarks a gradient‐based algorithm (L–BFGS–B) against a global search
  (Differential Evolution) and reports the optimum area distribution.

### Running the script

```
python fea_loop.py
```

The script prints the optimal cross‐sectional areas for each element,
the resulting compliance, and the computation time for each algorithm.

### Extending the example

Although this example uses a simple 1D beam, the same principles apply to
complex structures.  In more realistic settings you would:

* Replace the internal FEA with calls to a full solver (e.g., Abaqus, Ansys
  via scripting) or open source tools (e.g., FEniCS).  The loop structure and
  optimisation interface remain the same.
* Include multiple loading conditions and evaluate stresses or margins of
  safety, not just compliance.
* Post–process results consistently to ensure fair comparisons between
  optimisation algorithms.

"""Optimise the fibre orientations of a variable–angle tow (VAT) laminate.

This script defines a simple optimisation problem: maximise the bending stiffness
`Dₓₓ` of a symmetric four–ply laminate.  Two optimisation algorithms are
benchmarked: a local gradient–based search (BFGS) and a global metaheuristic
(Differential Evolution).  The script prints the optimum angles and resulting
stiffness for each method and reports the computational time required.

Usage:

    python optimise_vat.py

Author: Composite design demonstration
"""

import time
import numpy as np
from scipy import optimize

from utils import lamina_q, transform_q, laminate_abd


def objective(angles_pair: np.ndarray, material: dict, thickness: float) -> float:
    """Objective function for optimisation.

    Given a pair of orientation angles (degrees) representing the outer and inner
    plies of a symmetric laminate, compute the negative of the bending stiffness
    `Dₓₓ`.  Minimising this objective therefore maximises bending stiffness.

    Parameters
    ----------
    angles_pair : ndarray length 2
        The fibre angles for plies 1 and 2.  The laminate layup is
        [θ₁/θ₂/θ₂/θ₁].
    material : dict
        Dictionary with keys 'E1', 'E2', 'v12', 'G12'.
    thickness : float
        Thickness of each ply (assumed identical for all plies).

    Returns
    -------
    float
        Negative of Dₓₓ (bending stiffness).  Lower values correspond to
        stiffer laminates.
    """
    theta1, theta2 = angles_pair
    # Build lamina Q
    Q = lamina_q(material['E1'], material['E2'], material['v12'], material['G12'])
    # Build list of transformed Q for each ply
    orientations = [theta1, theta2, theta2, theta1]
    Qbars = [transform_q(Q, th) for th in orientations]
    thicknesses = [thickness] * 4
    _, _, D = laminate_abd(Qbars, thicknesses)
    D_xx = D[0, 0]
    # minimise negative of D_xx to maximise D_xx
    return -D_xx


def optimise_angles(material: dict, thickness: float, bounds: list) -> dict:
    """Run both optimisation algorithms and return their results.

    Parameters
    ----------
    material : dict
        Material properties (see `objective`).
    thickness : float
        Ply thickness in metres.
    bounds : list of tuple
        Bounds for the angle variables [(min_theta1, max_theta1), (min_theta2, max_theta2)].

    Returns
    -------
    results : dict
        Dictionary containing results for 'bfgs' and 'de' with keys:
        'angles' (ndarray), 'D_xx' (float), 'time' (float seconds).
    """
    results = {}
    # Gradient–based optimisation (BFGS)
    def obj_local(x):
        return objective(x, material, thickness)
    x0 = np.array([(b[0] + b[1]) / 2.0 for b in bounds])
    t0 = time.time()
    bfgs_res = optimize.minimize(
        obj_local,
        x0=x0,
        bounds=bounds,
        method='L-BFGS-B',
    )
    dt_bfgs = time.time() - t0
    angles_bfgs = bfgs_res.x
    D_xx_bfgs = -objective(angles_bfgs, material, thickness)
    results['bfgs'] = {'angles': angles_bfgs, 'D_xx': D_xx_bfgs, 'time': dt_bfgs}
    # Differential Evolution (global search)
    t0 = time.time()
    de_res = optimize.differential_evolution(
        lambda x: objective(x, material, thickness),
        bounds=bounds,
        tol=1e-3,
        polish=True,
    )
    dt_de = time.time() - t0
    angles_de = de_res.x
    D_xx_de = -objective(angles_de, material, thickness)
    results['de'] = {'angles': angles_de, 'D_xx': D_xx_de, 'time': dt_de}
    return results


def main():
    # Material properties for a generic carbon–epoxy lamina
    material = {
        'E1': 150e9,  # Pa
        'E2': 10e9,   # Pa
        'v12': 0.3,
        'G12': 5e9,   # Pa
    }
    # Ply thickness (e.g., 0.125 mm)
    thickness = 0.125e-3
    # Bounds for ply angles (±45 degrees)
    bounds = [(-45.0, 45.0), (-45.0, 45.0)]
    print("Optimising a symmetric four–ply VAT laminate for maximum bending stiffness...")
    results = optimise_angles(material, thickness, bounds)
    for method, res in results.items():
        print(f"\nMethod: {method.upper()}")
        ang = res['angles']
        print(f"  Optimal angles (deg): θ1 = {ang[0]:.2f}, θ2 = {ang[1]:.2f}")
        print(f"  D_xx (N⋅m): {res['D_xx']:.3e}")
        print(f"  Computation time: {res['time']:.3f} s")


if __name__ == '__main__':
    main()
